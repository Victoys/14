#!/bin/bash
export PATH=/usr/bin:/bin:/sbin:/usr/sbin
killall sogouhaomatong 1>/dev/null 2>/dev/null
dpkg -P $1 2>/tmp/sogou_unistall.txt 1>/dev/null
exitcode=$?
#rm -rf /tmp/sogou_unistall.txt 1>/dev/null 2>/dev/null
sleep 2
killall SpringBoard 1>/dev/null 2>/dev/null
exit $exitcode
