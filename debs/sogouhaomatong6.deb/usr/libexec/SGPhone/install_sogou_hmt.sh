#!/bin/bash
export PATH=/usr/bin:/bin:/sbin:/usr/sbin
dpkg -i $1 2>/tmp/sogou_haomatong_intall.txt 1>/dev/null
exitcode=$?
exit $exitcode
~                                                                                                                                              
~                  
